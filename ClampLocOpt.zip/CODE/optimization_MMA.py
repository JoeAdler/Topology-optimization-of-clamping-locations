"""
OPTIMIZATION (MMA)
------------------

Description: This code applies the MMA code from Arjen Deetman to the optimization of clamping locations.
             Note: the original code for the MMA solver + examples has been written by Krister Svanberg in MATLAB
             and has been translated to Python by Arjen Deetman.

Author: J. Adler

Academic year: 2024-2025
"""

from __future__ import division

import sys
import os

# Manually specify the absolute path to the mmapy/src folder
mma_src_path = "MMA/arjendeetman-GCMMA-MMA-Python-ce86d94/src"

# Add the path to Python's module search path
if mma_src_path not in sys.path:
    sys.path.append(mma_src_path)

from mmapy import mmasub, kktcheck
from util import setup_logger
from typing import Tuple
import numpy as np
import scipy
import inputs
import assembly
import sensitivity
import display
import time

#Start timer
start = time.time()

#Number of bars remaining at the end
V = 10
Omega = 4000 #[Hz]

def solve(m, n, optimization_problem, formulation='standard', q=1, log_name='default'):
    '''
    Parameters
    ----------
    m : int
        Number of constraint functions.
    n : int
        Number of design variables.
    optimization_problem : function (xval: np.ndarray) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray]
        Description of the optimization problem. This function return the value of the objective and constraint
        functions at the current point as well as the values of the derivatives at the current design point.
    log_name : string, optional
        Name of the logfile that is generated when calling the function. The default is 'default'.

    Returns
    -------
    The solution to the structural optimization problem.

    '''
    # Logger
    path = os.path.dirname(os.path.realpath(__file__))
    file = os.path.join(path, log_name+".log")
    logger = setup_logger(file)
    logger.info("Started\n")
    
    # Set numpy print options
    np.set_printoptions(precision=4, formatter={'float': '{: 0.4f}'.format})
    
    # Initial settings
    #m, n = 2, 3
    eeen = np.ones((n, 1))
    eeem = np.ones((m, 1))
    zeron = np.zeros((n, 1))
    zerom = np.zeros((m, 1))
    xval = np.ones(n).reshape(-1,1) *V/n
    xold1 = xval.copy()
    xold2 = xval.copy()
    xmin = zeron.copy()
    xmax = 1 * eeen
    low = xmin.copy()
    upp = xmax.copy()
    move = 1.0
    c = 1000 * eeem
    d = eeem.copy()
    a0 = 1
    
    if formulation=='standard':
        a = zerom.copy()
    elif formulation=='min-max':
        a = eeem.copy()
        a[m-q:] = np.zeros((2,1))
        
    innerit = 0
    outeriter = 0
    maxoutit = 99
    kkttol = 1e-3
    
    # Calculate function values and gradients of the objective and constraints functions
    if outeriter == 0:
        f0val, df0dx, fval, dfdx = optimization_problem(xval)
        outvector1 = np.concatenate((np.array([outeriter, innerit, f0val]), fval.flatten()))
        outvector2 = xval.flatten()
        
        # Log
        logger.info("outvector1 = {}".format(outvector1))
        logger.info("outvector2 = {}\n".format(outvector2))
    
    # The iterations start
    kktnorm = kkttol + 10
    outit = 0
    
    while kktnorm > kkttol and outit < maxoutit:
        outit += 1
        outeriter += 1
        
        # The MMA subproblem is solved at the point xval:
        xmma, ymma, zmma, lam, xsi, eta, mu, zet, s, low, upp = mmasub(
            m, n, outeriter, xval, xmin, xmax, xold1, xold2, f0val, df0dx, fval, dfdx, low, upp, a0, a, c, d, move)
        
        # Some vectors are updated:
        xold2 = xold1.copy()
        xold1 = xval.copy()
        xval = xmma.copy()
        
        # Re-calculate function values and gradients of the objective and constraints functions
        f0val, df0dx, fval, dfdx = optimization_problem(xval)
        
        # The residual vector of the KKT conditions is calculated
        residu, kktnorm, residumax = kktcheck(
            m, n, xmma, ymma, zmma, lam, xsi, eta, mu, zet, s, xmin, xmax, df0dx, fval, dfdx, a0, a, c, d)
        #print("Z=",zmma)
        #print("Y=",ymma)
        outvector1 = np.concatenate((np.array([outeriter, innerit, f0val]), fval.flatten()))
        outvector2 = xval.flatten()
        
        # Log
        logger.info("outvector1 = {}".format(outvector1))
        logger.info("outvector2 = {}".format(outvector2))
        logger.info("kktnorm    = {}\n".format(kktnorm))
    
    # Final log
    logger.info("Finished")
    return outvector2, outit

#Number of function evaluations
nfev = np.array([0])
fvals = []

def increment(nfev, fval0, fval1, fval2):
    nfev[0] += 1
    fvals.append([fval0, fval1, fval2])



'''Optimization problem without reduction'''
if True:
    #Number of constraints functions
    m = 1
    q = 1
    
    #Mesh data
    K_w = assembly.applyBC(assembly.K_workpiece())
    F = assembly.applyBC(assembly.f_individual(), dim=1)
    
    #Optimization problem with only the 1st constraint and for a single load (no reduction !)
    def clamploc(xval: np.ndarray) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray]:
        #Objective function value:
        K_b = assembly.applyBC(assembly.K_bars(xval.flatten()))
        K = K_w + K_b
        
        #Solve the system
        q = np.linalg.solve(K, F) * 1e6
        q_sq = q**2
        f0val = q_sq.max()
        
        #Sensitivity of the objective function:
        df0dx = sensitivity.dc0_dx(xval.flatten(), K, q).reshape(-1, 1)
        
        #Constraint function values:
        fval1 = xval.sum() - V
        fval = np.array([[fval1]])
        
        #Derivative of constraint functions:
        dfdx1 = sensitivity.dc1_dx()
        dfdx = np.array([dfdx1])
        
        increment(nfev, f0val, fval1, 0)
        return f0val, df0dx, fval, dfdx
    
    formulation = 'standard'
    opt_prob = clamploc


'''Optimization problem with reduction'''
if False:
    #Number of constraints functions
    m = 1
    q = 1
    
    #Mesh data
    K_w_tilde, R = assembly.K_workpiece_tilde()
    F_tilde = assembly.f_individual_tilde(R)
    
    #Optimization problem for multiple load cases (with reduction !)
    def clamplocred(xval: np.ndarray) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray]:
        #Objective function value:
        K_b_tilde = assembly.K_bars_tilde(xval.flatten())
        K_tilde = K_w_tilde + K_b_tilde
        
        #Solve the system
        q_tilde = np.linalg.solve(K_tilde, F_tilde) * 1e6
        q = R @ q_tilde
        q_sq = q**2
        f0val = q_sq.max()
        
        #Sensitivity of the objective function:
        df0dx = sensitivity.dc0_dx_tilde(xval.flatten(), R, q, q_tilde, K_tilde).reshape(-1, 1)
        
        #Constraint function values:
        fval1 = xval.sum() - V
        fval = np.array([[fval1]])
        
        #Derivative of constraint functions:
        dfdx1 = sensitivity.dc1_dx()
        dfdx = np.array([dfdx1])
        
        increment(nfev, f0val, fval1, 0)
        return f0val, df0dx, fval, dfdx
    
    formulation = 'standard'
    opt_prob = clamplocred


'''Optimization problem with reduction and lower bound
   on the 1st eigenfrequency'''
if False:
    #Number of constraints functions
    m = 2
    q = 2
    
    #Mesh data
    K_w_tilde, R = assembly.K_workpiece_tilde()
    M_w_tilde = assembly.M_workpiece_tilde(R)
    F_tilde = assembly.f_individual_tilde(R)
    
    #Optimization problem for multiple load cases (with reduction !) and
    #with constraint on the 1st eigenfrequency
    def clamplocred_freq(xval: np.ndarray) -> Tuple[float, np.ndarray, np.ndarray, np.ndarray]:
        #Objective function value:
        K_b_tilde = assembly.K_bars_tilde(xval.flatten())
        K_tilde = K_w_tilde + K_b_tilde
        
        #Solve the system
        q_tilde = np.linalg.solve(K_tilde, F_tilde) * 1e6
        q = R @ q_tilde
        q_sq = q**2
        f0val = q_sq.max()
        
        #Sensitivity of the objective function:
        df0dx = sensitivity.dc0_dx_tilde(xval.flatten(), R, q, q_tilde, K_tilde).reshape(-1, 1)
        
        #Constraint function values:
        fval1 = xval.sum() - V
        
        M_b_tilde = assembly.M_bars_tilde(xval.flatten())
        M_tilde = M_w_tilde + M_b_tilde
        eigenvals, eigenvecs = scipy.linalg.eigh(K_tilde, M_tilde)
        w1 = eigenvals[0]
        freq = np.sqrt(w1)/(2*np.pi)
        q1 = eigenvecs[:,0]
        
        fval2 = Omega - freq
        fval = np.array([[fval1],
                         [fval2]])
        
        #Derivative of constraint functions:
        dfdx1 = sensitivity.dc1_dx()
        dfdx2 = sensitivity.dc2_dx(xval.flatten(), w1, q1, reduced=True) / (8*np.pi**2 * freq)
        dfdx = np.array([dfdx1, dfdx2])
        
        increment(nfev, f0val, fval1, fval2)
        return f0val, df0dx, fval, dfdx
    
    formulation = 'standard'
    opt_prob = clamplocred_freq



#Solve the optimization problem
opt = solve(m, inputs.barElem, opt_prob, formulation=formulation, q=q)
x_star = opt[0]
nit = opt[1]

#End timer
end = time.time()
elapsed_time = np.round(end - start, 1)
print("Elapsed time:", elapsed_time, "sec")

#Plot the solution
display.plot_solution(inputs.nodeList, inputs.elemListBars, x_star)
print(inputs.dofs)
