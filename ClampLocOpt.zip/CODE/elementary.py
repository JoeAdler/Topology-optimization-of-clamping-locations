"""
ELEMENTARY
----------

Description: This code contains the elementary stiffness and mass matrices.

Author: J. Adler

Academic year: 2024-2025
"""


import numpy as np
import inputs

#Define D matrix relating the strains and the stress for an isotropic material
def D(E, nu):
    return np.array([[1-nu, nu, nu, 0, 0, 0],
                     [nu, 1-nu, nu, 0, 0, 0],
                     [nu, nu, 1-nu, 0, 0, 0],
                     [0, 0, 0, 0.5-nu, 0, 0],
                     [0, 0, 0, 0, 0.5-nu, 0],
                     [0, 0, 0, 0, 0, 0.5-nu]]) * E/((1+nu)*(1-2*nu))

#Define elementary stiffness matrix of T4 element
def Ke_T4(elem, E, nu):
    
    e = int(elem-1)
    nodesInElem = inputs.elemListWorkpiece[e]
    n1, n2, n3, n4 = nodesInElem[:] #Nodes in the tetrahedral element
    
    n1 = int(n1-1)
    n2 = int(n2-1)
    n3 = int(n3-1)
    n4 = int(n4-1) #Indices of the nodes
    
    x1, y1, z1 = inputs.nodeList[n1]
    x2, y2, z2 = inputs.nodeList[n2]
    x3, y3, z3 = inputs.nodeList[n3]
    x4, y4, z4 = inputs.nodeList[n4]
    
    x14, x24, x34 = x1-x4, x2-x4, x3-x4
    y14, y24, y34 = y1-y4, y2-y4, y3-y4
    z14, z24, z34 = z1-z4, z2-z4, z3-z4
    
    J = np.array([[x14, y14, z14],
                  [x24, y24, z24],
                  [x34, y34, z34]]) #Jacobian
    
    det_J = x14 * (y24*z34 - y34*z24) + y14 * (z24*x34 - z34*x24) + z14 * (x24*y34 - x34*y24) #Determinant of Jacobian
    
    A = np.array([[y24*z34 - y34*z24, y34*z14 - y14*z34, y14*z24 - y24*z14],
                  [z24*x34 - z34*x24, z34*x14 - z14*x34, z14*x24 - z24*x14],
                  [x24*y34 - x34*y24, x34*y14 - x14*y34, x14*y24 - x24*y14]]) / det_J #Inverse of Jacobian
    
    A1 = A[0].sum()
    A2 = A[1].sum()
    A3 = A[2].sum()
    
    B = np.array([[A[0,0], 0, 0, A[0,1], 0, 0, A[0,2], 0, 0, -A1, 0, 0],
                  [0, A[1,0], 0, 0, A[1,1], 0, 0, A[1,2], 0, 0, -A2, 0],
                  [0, 0, A[2,0], 0, 0, A[2,1], 0, 0, A[2,2], 0, 0, -A3],
                  [0, A[2,0], A[1,0], 0, A[2,1], A[1,1], 0, A[2,2], A[1,2], 0, -A3, -A2],
                  [A[2,0], 0, A[0,0], A[2,1], 0, A[0,1], A[2,2], 0, A[0,2], -A3, 0, -A1],
                  [A[1,0], A[0,0], 0, A[1,1], A[0,1], 0, A[1,2], A[0,2], 0, -A2, -A1, 0]]) #B matrix relating nodal displacement to strains
    
    
    ke = abs(det_J)/6 * (B.T @ D(E,nu) @ B) #Elementary stiffness matrix
    
    return ke

#Define elementary stiffness matrix of bar element
def Ke_bar(elem, E, A):
    
    e = int(elem-1)
    nodesInElem = inputs.elemListBars[e]
    n1, n2 = nodesInElem[:] #Nodes in the bar element
    
    n1 = int(n1-1)
    n2 = int(n2-1) #Indices of the nodes
    
    x1, y1, z1 = inputs.nodeList[n1]
    x2, y2, z2 = inputs.nodeList[n2]
    
    dX = x2 - x1
    dY = y2 - y1
    dZ = z2 - z1
    
    L = np.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
    
    return np.array([[dX**2, dX*dY, dX*dZ, -dX**2, -dX*dY, -dX*dZ],
                     [dX*dY, dY**2, dY*dZ, -dX*dY, -dY**2, -dY*dZ],
                     [dX*dZ, dY*dZ, dZ**2, -dX*dZ, -dY*dZ, -dZ**2],
                     [-dX**2, -dX*dY, -dX*dZ, dX**2, dX*dY, dX*dZ],
                     [-dX*dY, -dY**2, -dY*dZ, dX*dY, dY**2, dY*dZ],
                     [-dX*dZ, -dY*dZ, -dZ**2, dX*dZ, dY*dZ, dZ**2]]) * (E*A / L**3)

#Define elementary mass matrix of bar elements
def Me_bar(elem, A, rho):
    
    e = int(elem-1)
    nodesInElem = inputs.elemListBars[e]
    n1, n2 = nodesInElem[:]
    
    n1 = int(n1-1)
    n2 = int(n2-1)
    
    x1, y1, z1 = inputs.nodeList[n1]
    x2, y2, z2 = inputs.nodeList[n2]
    
    L = np.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
    
    return np.array([[2, 0, 0, 1, 0, 0],
                     [0, 2, 0, 0, 1, 0],
                     [0, 0, 2, 0, 0, 1],
                     [1, 0, 0, 2, 0 ,0],
                     [0, 1, 0, 0, 2, 0],
                     [0, 0, 1, 0, 0, 2]]) * (rho*A*L/6)

#Define elementary mass matrix of T4 elements
def Me_T4(elem, rho):
    
    e = int(elem-1)
    nodesInElem = inputs.elemListWorkpiece[e]
    n1, n2, n3, n4 = nodesInElem[:] #Nodes in the tetrahedral element
    
    n1 = int(n1-1)
    n2 = int(n2-1)
    n3 = int(n3-1)
    n4 = int(n4-1) #Indices of the nodes
    
    x1, y1, z1 = inputs.nodeList[n1]
    x2, y2, z2 = inputs.nodeList[n2]
    x3, y3, z3 = inputs.nodeList[n3]
    x4, y4, z4 = inputs.nodeList[n4]
    
    x14, x24, x34 = x1-x4, x2-x4, x3-x4
    y14, y24, y34 = y1-y4, y2-y4, y3-y4
    z14, z24, z34 = z1-z4, z2-z4, z3-z4
    
    det_J = x14 * (y24*z34 - y34*z24) + y14 * (z24*x34 - z34*x24) + z14 * (x24*y34 - x34*y24) #Determinant of Jacobian
    Ve = np.abs(det_J)/6
    
    return np.array([[2, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0],
                     [0, 2, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0],
                     [0, 0, 2, 0, 0, 1, 0, 0, 1, 0, 0, 1],
                     [1, 0, 0, 2, 0, 0, 1, 0, 0, 1, 0, 0],
                     [0, 1, 0, 0, 2, 0, 0, 1, 0, 0, 1, 0],
                     [0, 0, 1, 0, 0, 2, 0, 0, 1, 0, 0, 1],
                     [1, 0, 0, 1, 0, 0, 2, 0, 0, 1, 0, 0],
                     [0, 1, 0, 0, 1, 0, 0, 2, 0, 0, 1, 0],
                     [0, 0, 1, 0, 0, 1, 0, 0, 2, 0, 0, 1],
                     [1, 0, 0, 1, 0, 0, 1, 0, 0, 2, 0, 0],
                     [0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 2, 0],
                     [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 2]]) * (rho*Ve/20)

