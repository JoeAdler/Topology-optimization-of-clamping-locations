"""
VALIDATION
----------

Description: This code is aimed at validation the FEM code from the main files.

Author: J. Adler

Academic year: 2024-2025
"""

import numpy as np
import scipy
import inputs
import assembly
import display
import reduction


if False:
    #VALIDATION (CANTILEVER STIFFNESS)
    #----------
    
    #Compute stiffness matrix
    K_w = assembly.K_workpiece()
    #Compute force vector
    F = assembly.f()
    
    #Apply boundary conditions
    K_w = assembly.applyBC(K_w)
    F = assembly.applyBC(F, dim=1)
    
    #Solve the system
    q = np.linalg.solve(K_w, F)
    
    #Compute the new node coordinates
    Q = assembly.q_full(q)
    Q = Q.reshape(-1,3)
    
    newNodeList = inputs.nodeList + Q
    
    #Display the deformed mesh
    fixed = inputs.fixedList - 1
    fixed = inputs.nodeList[fixed.astype(int)]
    
    force_nodes = np.array(inputs.loadList[:,0] - 1, dtype=int)
    force_nodes = inputs.nodeList[force_nodes]
    
    force_vectors = inputs.loadList[:,1:]
    
    displacement_values = np.sqrt(np.sum(Q**2, axis=1))
    
    display.plot_mesh(newNodeList,
                      fixed=fixed,
                      force_nodes=force_nodes,
                      force_vectors=force_vectors,
                      force_scale=1,
                      values=displacement_values*1000)
    
    print("Max displacement:", np.round(displacement_values.max()*1000, 3), "[mm]")


if False:
    #VALIDATION (BARS STIFFNESS)
    #----------
    
    #Compute stiffness matrix
    K_b = assembly.K_bars(np.ones(3))
    #Compute force vector
    F = assembly.f()
    
    #Apply boundary conditions
    K_b = assembly.applyBC(K_b)
    F = assembly.applyBC(F, dim=1)
    
    #Solve the system
    q = np.linalg.solve(K_b, F)
    
    #Plot the initial bars
    bars = inputs.elemListBars
    
    fixed = np.array(inputs.fixedList - 1, dtype=int)
    fixed = inputs.nodeList[fixed]
    
    force_nodes = np.array(inputs.loadList[:,0]-1, dtype=int)
    force_nodes = inputs.nodeList[force_nodes]
    
    force_vectors = inputs.loadList[:,1:]
    
    display.plot_bars(inputs.nodeList,
                      bars,
                      fixed=fixed,
                      force_nodes=force_nodes,
                      force_vectors=force_vectors,
                      force_scale=5e-3)
    
    #Compute the new node coordinates
    Q = assembly.q_full(q)
    Q = Q.reshape(-1,3)
    
    newNodeList = inputs.nodeList + Q
    
    #Plot the deformed bars
    force_nodes = np.array(inputs.loadList[:,0]-1, dtype=int)
    force_nodes = newNodeList[force_nodes]
    
    display.plot_bars(newNodeList,
                      bars,
                      fixed=fixed,
                      force_nodes=force_nodes,
                      force_vectors=force_vectors,
                      force_scale=5e-2)
    
    #Node displacement
    node_displacement = np.sqrt(np.sum(q**2))
    
    print("Node displacement:", np.round(node_displacement*1000,3))

if False:
    #VALIDATION (BARS MASS)
    #----------
    
    #Compute stiffness matrix
    K_b = assembly.K_bars(np.ones(3))
    #Compute mass matrix
    M_b = assembly.M_bars(np.ones(3))
    
    #Apply boundary conditions
    K_b = assembly.applyBC(K_b)
    M_b = assembly.applyBC(M_b)
    
    # K and M should be symmetric and positive definite
    eigenvals, eigenvecs = scipy.linalg.eigh(K_b, M_b)
    
    # Eigenfrequencies (rad/s)
    omega = np.sqrt(eigenvals)
    
    # Frequencies in Hz
    freqs = omega / (2 * np.pi)
    
    print("Frequencies (Hz):", freqs)
    
    
if False:
    #VALIDATION (CANTILEVER MASS)
    #----------
    
    #Compute stiffness matrix
    K_w = assembly.K_workpiece()
    #Compute mass matrix
    M_w = assembly.M_workpiece()
    
    #Apply boundary conditions
    K_w = assembly.applyBC(K_w)
    M_w = assembly.applyBC(M_w)
    
    # K and M should be symmetric and positive definite
    eigenvals, eigenvecs = scipy.linalg.eigh(K_w, M_w)
    
    # Eigenfrequencies (rad/s)
    omega = np.sqrt(eigenvals)
    
    # Frequencies in Hz
    freqs = omega / (2 * np.pi)
    
    print("Frequencies (Hz):", freqs)
    
    #Display the deformed mesh
    Q = assembly.q_full(eigenvecs[:,2])
    Q = Q.reshape(-1,3)
    
    newNodeList = inputs.nodeList + Q/2
    
    fixed = inputs.fixedList - 1
    fixed = inputs.nodeList[fixed.astype(int)]
    
    displacement_values = np.sqrt(np.sum(Q**2, axis=1))
    
    display.plot_mesh(newNodeList,
                      fixed=fixed,
                      values=displacement_values*10/3)

    
if True:
    #VALIDATION (GUYAN-IRONS, CANTILEVER)
    #----------
    
    #Compute stifness matrix
    K_w = assembly.K_workpiece()
    M_w = assembly.M_workpiece()
    #Compute force vector
    f = assembly.f()
    
    #Apply boundary conditions
    K_w = assembly.applyBC(K_w)
    M_w = assembly.applyBC(M_w)
    f = assembly.applyBC(f, dim=1)
    
    #Guyan-Irons
    retained_dofs, condensed_dofs = reduction.get_relevant_dofs()
    retained = reduction.get_retained_indices(retained_dofs)
    R = reduction.R_gi(K_w, retained)
    K_red = reduction.K_gi(K_w, R)
    M_red = reduction.M_gi(M_w, R)
    f_red = reduction.f_gi(f, R)
    
    q_red = np.linalg.solve(K_red, f_red)
    q = R @ q_red
    Q = assembly.q_full(q)
    Q = Q.reshape(-1,3)
    
    newNodeList = inputs.nodeList + Q
    
    #Display the deformed mesh
    fixed = inputs.fixedList - 1
    fixed = inputs.nodeList[fixed.astype(int)]
    
    force_nodes = np.array(inputs.loadList[:,0] - 1, dtype=int)
    force_nodes = inputs.nodeList[force_nodes]
    
    force_vectors = inputs.loadList[:,1:]
    
    displacement_values = np.sqrt(np.sum(Q**2, axis=1))
    
    display.plot_mesh(newNodeList,
                      fixed=fixed,
                      force_nodes=force_nodes,
                      force_vectors=force_vectors,
                      force_scale=1,
                      values=displacement_values*1000)
    
    #Eigenvalue problem
    eigenvals, eigenvecs = scipy.linalg.eigh(K_red, M_red)
    eigenvecs = R @ eigenvecs
    
    # Eigenfrequencies (rad/s)
    omega = np.sqrt(eigenvals)
    
    # Frequencies in Hz
    freqs = omega / (2 * np.pi)
    
    #Display the deformed mesh
    Q = assembly.q_full(eigenvecs[:,1])
    Q = Q.reshape(-1,3)
    
    newNodeList = inputs.nodeList + Q/2
    
    fixed = inputs.fixedList - 1
    fixed = inputs.nodeList[fixed.astype(int)]
    
    displacement_values = np.sqrt(np.sum(Q**2, axis=1))
    
    display.plot_mesh(newNodeList,
                      fixed=fixed,
                      values=displacement_values*10/3)
    
    print("Maximum displacement =", np.round(displacement_values.max()*1000, 3), "[mm]")
    print("Eigenfrequencies =", freqs, "[Hz]")
    
    
    
    
    