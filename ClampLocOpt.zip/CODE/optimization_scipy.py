"""
OPTIMIZATION (SCIPY)
--------------------

Description: This code runs the optimization process.

Author: J. Adler

Academic year: 2024-2025
"""


import numpy as np
from scipy.optimize import minimize
import inputs
import assembly
import display
import time

#Define the number of bars in the solution
V = 10

#Define the objective function to minimize
def objective(x):
    
    K_w = assembly.K_workpiece()
    K_b = assembly.K_bars(x)
    K = K_w + K_b
    
    F = assembly.f()
    
    K = assembly.applyBC(K)
    F = assembly.applyBC(F, dim=1)
    
    q = np.linalg.solve(K, F) * 1e6
    q_sq = q**2
    
    return q_sq.max()

#Define the inequality constraints
def ineq_constraints(x):
    
    return V - x.sum()

# Define the callback function
def callback(xk):
    print(f"Current iteration result: {xk}\n")

#Define the initial guess
initial_guess = np.ones(inputs.barElem)*V/inputs.barElem

#Define the bounds
bounds = [(0, 1) for _ in range(inputs.barElem)]

#Define the constraints
constraints = ({'type': 'ineq', 'fun': ineq_constraints})

#Start timer
start = time.time()

#Minimize the objective function with the imposed constraints
opt = minimize(objective,
               initial_guess,
               method='SLSQP',
               bounds=bounds,
               constraints=constraints,
               callback=callback)

#End timer
end = time.time()
elapsed_time = np.round(end - start, 1)
print("Elapsed time:", elapsed_time, "sec")

#Print the results
print(opt)

#Plot the solution
sol = opt['x']
display.plot_solution(inputs.nodeList, inputs.elemListBars, sol)