"""
INPUTS
------

Description: This code processes the input files.

Author: J. Adler

Academic year: 2024-2025
"""


import numpy as np

#Extract node list
nodeList = np.loadtxt('Inputs/nodeList.txt')/1000 #[m]

nodes, dofPerNode = nodeList.shape

#Extract workpiece element list
elemListWorkpiece = np.loadtxt('Inputs/elemListWorkpiece.txt', dtype=int)

workpieceElem = len(elemListWorkpiece)

#Extract bars element list
elemListBars = np.loadtxt('Inputs/elemListBars.txt', dtype=int)

barElem = len(elemListBars)

#Define dof list
dofList = np.zeros((nodes, dofPerNode))

for i in range(nodes):
    for j in range(dofPerNode):
        dofList[i,j] = 1 + j + 3*i

#Define locel matrices
locelWorkpiece = np.zeros((workpieceElem, 4*dofPerNode))

for i in range(workpieceElem):
    for j in range(4):
        
        J = dofPerNode*j
        JJ = dofPerNode*(j+1)
        
        locelWorkpiece[i,J:JJ] = dofList[elemListWorkpiece[i][j]-1]

locelBars = np.zeros((barElem, 2*dofPerNode))

for i in range(barElem):
    for j in range(2):
        
        J = dofPerNode*j
        JJ = dofPerNode*(j+1)
        
        locelBars[i,J:JJ] = dofList[elemListBars[i][j]-1]

#Extract fixed nodes list
fixedList = np.loadtxt('Inputs/fixedNodes.txt')

#Extract load list
loadList = np.loadtxt('Inputs/machiningLoads.txt')
if loadList.ndim==1:
    loadList = np.array([loadList])

#Define the total number of dofs
dofs = int(dofList.max())