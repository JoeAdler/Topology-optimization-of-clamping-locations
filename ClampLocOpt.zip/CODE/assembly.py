"""
ASSEMBLY
--------

Description: This code assembles the structural stiffness and mass matrices.

Author: J. Adler

Academic year: 2024-2025
"""


import numpy as np
import inputs
import elementary
import display
import reduction

#Define mechanical properties of the workpiece
E_w = 73.119 * 1e9 #[Pa]
nu_w = 0.33 #[-]
rho_w = 2700 #[kg/m^3]

#E_w = 206.94 * 1e9 #[Pa]
#nu_w = 0.288 #[-]
#rho_w = 7829 #[kg/m^3]

#Define mechanical properties of the bars
alpha = 1
#E_b = alpha * E_w
E_b = 206.94 * 1e9 #[Pa]
nu_b = nu_w #[-]
A_b = (10**2 * np.pi / 4) * 1e-6 #[m^2]
rho_b = rho_w #[kg/m^3]

#Penalization parameter
p_SIMP = 3

#Simply isotropic material with penalization
def E(x, p=p_SIMP):
    if p<1 or x<0 or 1<x:
        raise ValueError("Problem in 'E'")
    return E_b * x**p

def rho(x):
    if x<0 or 1<x:
        raise ValueError("Problem in 'rho'")
    return rho_b * x

#Define the structural workpiece stiffness matrix
def K_workpiece():
    
    K = np.zeros((inputs.dofs, inputs.dofs))
    
    for e in range(inputs.workpieceElem):
        ke = elementary.Ke_T4(e+1, E_w, nu_w) #Elementary stiffness matrix of tetrahedral elements
        
        loc = inputs.locelWorkpiece[e] - 1 #Indices of the dofs
        
        for i in range(4 * inputs.dofPerNode):
            for j in range(4 * inputs.dofPerNode):
                ii, jj = int(loc[i]), int(loc[j])
                K[ii, jj] += ke[i][j]
    
    return K

#Define the structural workpiece mass matrix
def M_workpiece():
    
    M = np.zeros((inputs.dofs, inputs.dofs))
    
    for e in range(inputs.workpieceElem):
        me = elementary.Me_T4(e+1, rho_w) #Elementary stiffness matrix of tetrahedral elements
        
        loc = inputs.locelWorkpiece[e] - 1 #Indices of the dofs
        
        for i in range(4 * inputs.dofPerNode):
            for j in range(4 * inputs.dofPerNode):
                ii, jj = int(loc[i]), int(loc[j])
                M[ii, jj] += me[i][j]
    
    return M

#Define the structural bars stiffness matrix
def K_bars(x):
    
    K = np.zeros((inputs.dofs, inputs.dofs))
    
    for e in range(inputs.barElem):
        ke = elementary.Ke_bar(e+1, E(x[e]), A_b) #Elementary stiffness matrix of bar elements
        
        loc = inputs.locelBars[e] - 1 #Indices of the dofs
        
        for i in range(2 * inputs.dofPerNode):
            for j in range(2 * inputs.dofPerNode):
                ii, jj = int(loc[i]), int(loc[j])
                K[ii, jj] += ke[i][j]
    
    return K

#Define the structural bars mass matrix
def M_bars(x):
    
    M = np.zeros((inputs.dofs, inputs.dofs))
    
    for e in range(inputs.barElem):
        me = elementary.Me_bar(e+1, A_b, rho(x[e])) #Elementary stiffness matrix of bar elements
        
        loc = inputs.locelBars[e] - 1 #Indices of the dofs
        
        for i in range(2 * inputs.dofPerNode):
            for j in range(2 * inputs.dofPerNode):
                ii, jj = int(loc[i]), int(loc[j])
                M[ii, jj] += me[i][j]
    
    return M

#Define the force vector
def f():
    
    F = np.zeros(inputs.dofs)
    
    for force in inputs.loadList:
        node_index = int(force[0]-1)
        i,j,k = inputs.dofList[node_index,:]
        
        i = int(i-1)
        j = int(j-1)
        k = int(k-1) #Indices of the dofs
        
        Fx, Fy, Fz = force[1:] #Components of the nodal force
        
        F[i] += Fx
        F[j] += Fy
        F[k] += Fz
    
    return F

#Matrix of force vectors for machining operation
def f_individual():
    
    F = np.zeros((inputs.dofs, len(inputs.loadList)))
    
    for i in range(len(inputs.loadList)):
        force = inputs.loadList[i]
        node_index = int(force[0]-1)
        I,J,K = inputs.dofList[node_index,:]
        
        I = int(I-1)
        J = int(J-1)
        K = int(K-1) #Indices of the dofs
        
        Fx, Fy, Fz = force[1:] #Components of the nodal force
        
        F[np.array([I,J,K]), i] = np.array([Fx, Fy, Fz])
        
    return F
        

#Apply the fixed nodes boundary conditions
def applyBC(K, dim=2):
    dofs_index = np.array([], dtype=int)

    for node in inputs.fixedList:
        node_index = int(node-1)
        dofs_index = np.concatenate((dofs_index, np.arange(inputs.dofPerNode * node_index, inputs.dofPerNode * (node_index+1), 1, dtype=int)), dtype=int)
        
    dofs_index = np.sort(dofs_index)

    row_mask = np.ones(len(K), dtype=bool)
    col_mask = np.ones(len(K), dtype=bool)

    row_mask[dofs_index] = False
    col_mask[dofs_index] = False
    
    if dim==2: #For K and M
        K = K[row_mask, :]
        K = K[:, col_mask]
        
        return K
    
    if dim==1: #For f
        K = K[row_mask]
        
        return K
    
    raise ValueError("Problem in 'applyBC'")

#Get full displacement vector (including fixed nodes)
def q_full(q):
    dofs_index = np.array([], dtype=int)

    for node in inputs.fixedList:
        node_index = int(node-1)
        dofs_index = np.concatenate((dofs_index, np.arange(inputs.dofPerNode * node_index, inputs.dofPerNode * (node_index+1), 1, dtype=int)), dtype=int)
        
    dofs_index = np.sort(dofs_index)
    
    Q = np.zeros(inputs.dofs)
    
    I = 0
    for i in range(inputs.dofs):
        if i in dofs_index:
            I += 1
            continue
        Q[i] = q[i-I]
    
    return Q

#Reduced stiffness matrix for the bars
def K_bars_tilde(x):
    #List of active bar nodes
    elemListBars = inputs.elemListBars.flatten()
    fixedList = inputs.fixedList
    active_nodes = np.sort([item for item in elemListBars if item not in fixedList])
    
    #Initialize the matrix
    n = inputs.dofPerNode * inputs.barElem
    K_b_tilde = np.zeros((n, n))
    
    #Loop over the bars
    for i in range(len(inputs.elemListBars)):
        n1, n2 = inputs.elemListBars[i][:]
        
        K_b_e = elementary.Ke_bar(i+1, E(x[i]), A_b)
        
        if n1 in active_nodes and n2 in active_nodes:
            raise ValueError("Problem in 'K_bars_tilde")
            
        elif n1 in active_nodes:
            I = np.where(active_nodes == n1)[0][0]
            J = I+1
            
            K_b_tilde[3*I:3*J, 3*I:3*J] += K_b_e[:3,:3]
        
        elif n2 in active_nodes:
            I = np.where(active_nodes == n2)[0][0]
            J = I+1
            
            K_b_tilde[3*I:3*J, 3*I:3*J] += K_b_e[3:,3:]
            
        else:
            raise ValueError("Problem in 'K_bars_tilde")
        
    return K_b_tilde

#Reduced mass matrix of the bars
def M_bars_tilde(x):
    #List of active bar nodes
    elemListBars = inputs.elemListBars.flatten()
    fixedList = inputs.fixedList
    active_nodes = np.sort([item for item in elemListBars if item not in fixedList])
    
    #Initialize the matrix
    n = inputs.dofPerNode * inputs.barElem
    M_b_tilde = np.zeros((n, n))
    
    #Loop over the bars
    for i in range(len(inputs.elemListBars)):
        n1, n2 = inputs.elemListBars[i][:]
        
        M_b_e = elementary.Me_bar(i+1, A_b, rho(x[i]))
        
        if n1 in active_nodes and n2 in active_nodes:
            raise ValueError("Problem in 'M_bars_tilde")
            
        elif n1 in active_nodes:
            I = np.where(active_nodes == n1)[0][0]
            J = I+1
            
            M_b_tilde[3*I:3*J, 3*I:3*J] += M_b_e[:3,:3]
        
        elif n2 in active_nodes:
            I = np.where(active_nodes == n2)[0][0]
            J = I+1
            
            M_b_tilde[3*I:3*J, 3*I:3*J] += M_b_e[3:,3:]
            
        else:
            raise ValueError("Problem in 'M_bars_tilde")
        
    return M_b_tilde

#Reduced stiffness matrix of the workpiece
def K_workpiece_tilde():
    #Structural stiffness matrix
    K_w = applyBC(K_workpiece())
    
    #Reduction
    retained_dofs = reduction.get_retained_dofs()
    retained_indices = reduction.get_retained_indices(retained_dofs)
    R = reduction.R_gi(K_w, retained_indices)
    
    K_w_tilde = reduction.K_gi(K_w, R)
    
    return K_w_tilde, R

#Reduced mass matrix of the workpiece
def M_workpiece_tilde(R):
    #Structural mass matrix
    M_w = applyBC(M_workpiece())
    
    return reduction.M_gi(M_w, R)
    

#Reduced force vector
def f_tilde(R):
    return R.T @ applyBC(f(), dim=1)

#Reduced force vector for multiple load cases
def f_individual_tilde(R):
    return R.T @ applyBC(f_individual(), dim=1)

display.plot(inputs.nodeList,
             inputs.elemListWorkpiece,
             inputs.elemListBars,
             inputs.fixedList,
             inputs.loadList,
             force_scale=5e-3)

