"""
DISPLAY
-------

Description: This code contains functions to display the results.

Author: J. Adler

Academic year: 2024-2025
"""


import numpy as np
import matplotlib.pyplot as plt
import inputs
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.animation import FuncAnimation, PillowWriter

#Define a function to display meshes
def plot_mesh(nodes, fixed=np.array([]), force_nodes=np.array([]), force_vectors=np.array([]), force_scale=1, values=np.array([])):
    '''
    Parameters
    ----------
    nodes : array
        Array containing the x, y and z coordinates of the nodes in the mesh (n,3).
    fixed : array, optional
        Array containing the x, y and z coordinates of the fixed nodes (n,3). The default is np.array([]).
    force_nodes : array, optional
        Array containing the x, y and z coordinates of the nodes on which the forces are applied (n,3). The default is np.array([]).
    force_vectors : array, optional
        Array containing the x, y and z coordinates of the force vectors (n,3). The default is np.array([]).
    force_scale: float
        Scale factor for the force vector.

    Raises
    ------
    ValueError
        Error when the shapes of the 'force_nodes'-array and 'force_vectors'-array are different.

    Returns
    -------
    Plots the mesh.

    '''
    
    if force_nodes.shape != force_vectors.shape:
        raise ValueError("Force arrays in 'plot_mesh' must have the same shape")
    
    #Nodes coordinates
    x = nodes[:,0] * 1000
    y = nodes[:,1] * 1000
    z = nodes[:,2] * 1000
    
    #Initialize figure
    fig = plt.figure()
    ax = plt.axes(projection ='3d')
    
    # Create cubic bounding box to simulate equal aspect ratio
    max_range = np.array([x.max()-x.min(), y.max()-y.min(), z.max()-z.min()]).max()
    Xb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][0].flatten() + 0.5*(x.max()+x.min())
    Yb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][1].flatten() + 0.5*(y.max()+y.min())
    Zb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][2].flatten() + 0.5*(z.max()+z.min())
    # Comment or uncomment following both lines to test the fake bounding box:
    for xb, yb, zb in zip(Xb, Yb, Zb):
       ax.plot([xb], [yb], [zb], 'w')
    
    #Plot the nodes
    ax.scatter(x, y, z, c = 'green', s=1)
    sc = ax.scatter(x, y, z, c = values, s=5, cmap="Spectral_r")
    plt.colorbar(sc, pad=0.1)
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    if len(fixed)!=0:
        
        #Fixed nodes coordinates
        x_f = fixed[:,0] * 1000
        y_f = fixed[:,1] * 1000
        z_f = fixed[:,2] * 1000
        
        #Plot the fixed nodes
        ax.scatter(x_f, y_f, z_f, c = 'black', s=10)
        
    
    if len(force_vectors)!=0:
        #Forces
        x_o = force_nodes[:,0] * 1000
        y_o = force_nodes[:,1] * 1000
        z_o = force_nodes[:,2] * 1000
        
        x_vec = force_vectors[:,0] * force_scale
        y_vec = force_vectors[:,1] * force_scale
        z_vec = force_vectors[:,2] * force_scale
        
        #Plot the forces
        for i in range(len(force_vectors)):
            ax.quiver(x_o[i], y_o[i], z_o[i], x_vec[i], y_vec[i], z_vec[i], color='red')
    
    #plt.savefig("Figures/impeller_no_clamps.pdf", format="pdf", bbox_inches="tight")
    plt.show()
    
    return


#Define a function to display bars
def plot_bars(nodes, bars, fixed=np.array([]), force_nodes=np.array([]), force_vectors=np.array([]), force_scale=1, values=np.array([])):
    
    #Nodes coordinates
    x = nodes[:,0] * 1000
    y = nodes[:,1] * 1000
    z = nodes[:,2] * 1000
    
    #Initialize the plot
    fig = plt.figure()
    ax = plt.axes(projection ='3d')
    
    # Create cubic bounding box to simulate equal aspect ratio
    max_range = np.array([x.max()-x.min(), y.max()-y.min(), z.max()-z.min()]).max()
    Xb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][0].flatten() + 0.5*(x.max()+x.min())
    Yb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][1].flatten() + 0.5*(y.max()+y.min())
    Zb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][2].flatten() + 0.5*(z.max()+z.min())
    # Comment or uncomment following both lines to test the fake bounding box:
    for xb, yb, zb in zip(Xb, Yb, Zb):
       ax.plot([xb], [yb], [zb], 'w')
    
    for bar in bars:
        n1_index = int(bar[0]-1)
        n2_index = int(bar[1]-1)
        
        x1, y1, z1 = x[n1_index], y[n1_index], z[n1_index]
        x2, y2, z2 = x[n2_index], y[n2_index], z[n2_index]
        
        xs = [x1, x2]
        ys = [y1, y2]
        zs = [z1, z2]
        
        ax.scatter(x1, y1, z1, c = 'green', s=1)
        ax.scatter(x2, y2, z2, c = 'green', s=1)
        ax.plot3D(xs, ys, zs, c='gray')
    
    if len(fixed)!=0:
        
        #Fixed nodes coordinates
        x_f = fixed[:,0] * 1000
        y_f = fixed[:,1] * 1000
        z_f = fixed[:,2] * 1000
        
        #Plot the fixed nodes
        ax.scatter(x_f, y_f, z_f, c = 'black', s=10)
        
    if len(force_vectors)!=0:
        #Forces
        x_o = force_nodes[:,0] * 1000
        y_o = force_nodes[:,1] * 1000
        z_o = force_nodes[:,2] * 1000
        
        x_vec = force_vectors[:,0] * force_scale
        y_vec = force_vectors[:,1] * force_scale
        z_vec = force_vectors[:,2] * force_scale
        
        #Plot the forces
        for i in range(len(force_vectors)):
            ax.quiver(x_o[i], y_o[i], z_o[i], x_vec[i], y_vec[i], z_vec[i], color='red')
        
    #plt.savefig("Figures/bar_truss.pdf", format="pdf", bbox_inches="tight")
    plt.show()
    
    return

#Define a function to display the optimization solution
def plot_solution(nodeList, barNodes, sol):
    '''

    Parameters
    ----------
    nodeList : numpy array (n x 3)
        Contains the coordinates of the nodes.
    barNodes : numpy array (n x 2)
        Contains the nodes of the bars.
    sol : numpy array (n)
        Contains the solution for each bar.

    Returns
    -------
    Plots the solution.

    '''
    
    #Nodes coordinates
    x = nodeList[:,0] * 1000
    y = nodeList[:,1] * 1000
    z = nodeList[:,2] * 1000
    
    #Concerned nodes
    indices = (barNodes[:,0] - 1).astype(int)
    
    x_s = x[indices]
    y_s = y[indices]
    z_s = z[indices]
    
    #Initialize the plot
    fig = plt.figure()
    ax = plt.axes(projection ='3d')
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    #Plot the nodes
    #'inferno_r'
    sc = ax.scatter(x_s, y_s, z_s, c=sol, s=50, cmap='binary', alpha=1, depthshade=False)
    plt.colorbar(sc, pad=0.1)
    #ax.set_zlim3d([-50,100])
    
    #Show
    #plt.savefig("Figures/SLSQP_2.pdf", format="pdf", bbox_inches="tight")
    plt.show()

#Define a function the solution + the mesh
def plot_solution_mesh(nodeList, workpieceNodes, barNodes, forceNodes, sol, generateGIF=False):
    
    workpieceCoordinates = nodeList[np.sort(np.unique(workpieceNodes)).astype(int) - 1]
    barCoordinates = nodeList[np.sort(np.unique(barNodes)).astype(int) - 1]
    forceCoordinates = nodeList[np.sort(np.unique(forceNodes)).astype(int) - 1]
    
    #Workpiece nodes coordinates
    x = workpieceCoordinates[:,0] * 1000
    y = workpieceCoordinates[:,1] * 1000
    z = workpieceCoordinates[:,2] * 1000
    
    #Solution nodes coordinates
    x_s = barCoordinates[:,0] * 1000
    y_s = barCoordinates[:,1] * 1000
    z_s = barCoordinates[:,2] * 1000
    
    #Force nodes coordniates
    x_f = forceCoordinates[:,0] * 1000
    y_f = forceCoordinates[:,1] * 1000
    z_f = forceCoordinates[:,2] * 1000
    
    #Initialize figure
    fig = plt.figure(dpi=200)
    ax = plt.axes(projection ='3d')
    
    # Create cubic bounding box to simulate equal aspect ratio
    max_range = np.array([x.max()-x.min(), y.max()-y.min(), z.max()-z.min()]).max()
    Xb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][0].flatten() + 0.5*(x.max()+x.min())
    Yb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][1].flatten() + 0.5*(y.max()+y.min())
    Zb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][2].flatten() + 0.5*(z.max()+z.min())
    # Comment or uncomment following both lines to test the fake bounding box:
    for xb, yb, zb in zip(Xb, Yb, Zb):
       ax.plot([xb], [yb], [zb], 'w')
    
    #Plot the nodes
    #cmap: 'plasma', 'viridis', 'binary', 'inferno'
    ax.scatter(x, y, z, c = 'green', s=0.5, marker="8")
    ax.scatter(x_f, y_f, z_f, c = 'red', s=5, zorder=1)
    sc = ax.scatter(x_s, y_s, z_s, c=sol, s=12, cmap='binary')
    ax.quiver(x_f[0], y_f[0], z_f[0], 50, 50, 0, color='red')
    plt.colorbar(sc, pad=0.1)
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    #elevation = 30
    #alpha = -60 + 3 * 90
    #ax.view_init(elev=elevation, azim=alpha)
    #plt.savefig("Figures/impeller_post-process.pdf", format="pdf", bbox_inches="tight")
    plt.show()
    
    
    if generateGIF:
        def update(frame):
            ax.view_init(elev=30, azim=frame)
            return sc,
    
        # Create the animation
        ani = FuncAnimation(fig, update, frames=np.arange(0, 360, 2), interval=50)
        
        # Save to GIF (requires Pillow)
        ani.save("Figures/gif.gif", writer=PillowWriter(fps=15))
    
    return

#Define a function to display the entire mesh (workpiece + bars)
def plot(nodeList, workpieceNodes, barNodes, fixedList, loadList, force_scale=1):
    '''

    Parameters
    ----------
    nodeList : numpy array (n x 3)
        Contains the coordinates of each node.
    workpieceNodes : numpy array
        Contains the nodes of the elements.
    barNodes : numpy array (n x 2)
        Contains the nodes of the bars.
    fixedList : numpy array
        Contains the fixed nodes.
    loadList : numpy array (n x 4)
        Contains the loads applied on the workpiece.
    force_scale : float, optional
        Can be tuned to change the force vector scale. The default is 1.

    Returns
    -------
    Plots the workpiece, the bars, the fixed nodes and the applied loads.

    '''
    
    #Nodes coordinates
    x = nodeList[:,0] * 1000
    y = nodeList[:,1] * 1000
    z = nodeList[:,2] * 1000
    
    #Initialize the plot
    fig = plt.figure()
    ax = plt.axes(projection='3d')
    #ax.set_xlabel("x")
    #ax.set_ylabel("y")
    #ax.set_zlabel("z")
    
    # Create cubic bounding box to simulate equal aspect ratio
    max_range = np.array([x.max()-x.min(), y.max()-y.min(), z.max()-z.min()]).max()
    Xb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][0].flatten() + 0.5*(x.max()+x.min())
    Yb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][1].flatten() + 0.5*(y.max()+y.min())
    Zb = 0.5*max_range*np.mgrid[-1:2:2,-1:2:2,-1:2:2][2].flatten() + 0.5*(z.max()+z.min())
    # Comment or uncomment following both lines to test the fake bounding box:
    for xb, yb, zb in zip(Xb, Yb, Zb):
       ax.plot([xb], [yb], [zb], 'w')
       
    #Plot the bars
    for bar in barNodes:
        n1_index = int(bar[0]-1)
        n2_index = int(bar[1]-1)
        
        x1, y1, z1 = x[n1_index], y[n1_index], z[n1_index]
        x2, y2, z2 = x[n2_index], y[n2_index], z[n2_index]
        
        xs = [x1, x2]
        ys = [y1, y2]
        zs = [z1, z2]
        
        #ax.scatter(x1, y1, z1, c = 'green', s=1)
        #ax.scatter(x2, y2, z2, c = 'green', s=1)
        ax.plot3D(xs, ys, zs, c='blue')
        
    #Plot the workpiece
    indices = (np.unique(workpieceNodes) - 1).astype(int)
    
    x_w = x[indices]
    y_w = y[indices]
    z_w = z[indices]
    
    ax.scatter(x_w, y_w, z_w, c = 'green', s=1)
    
    #Plot fixed nodes
    indices = (fixedList - 1).astype(int)
    
    x_f = x[indices]
    y_f = y[indices]
    z_f = z[indices]
    
    ax.scatter(x_f, y_f, z_f, c = 'black', s=5)
    
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    #Plot loads
    for load in loadList:
        index = (load[0] - 1).astype(int)
        
        x_o = x[index]
        y_o = y[index]
        z_o = z[index]
        
        x_vec, y_vec, z_vec = load[1:] * force_scale
        
        ax.quiver(x_o, y_o, z_o, x_vec, y_vec, z_vec, color='red')
    
    #Show
    #plt.savefig("Figures/cylinder_1.pdf", format="pdf", bbox_inches="tight")
    plt.show()
        

