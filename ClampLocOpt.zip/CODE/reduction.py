"""
REDUCTION
---------

Description: This file contains code for Guyan-Irons reduction method.

Author: J. Adler

Academic year: 2024-2025
"""

import numpy as np
import inputs

#Define a function to get the retained and condensed dofs
def get_retained_dofs():
    
    elemListBars = inputs.elemListBars.flatten()
    fixedList = inputs.fixedList
    
    retained_nodes = np.sort([item for item in elemListBars if item not in fixedList]).astype(int)
    
    retained_dofs = np.sort([inputs.dofList[item-1] for item in retained_nodes]).flatten().astype(int)
    
    return retained_dofs
    

def get_retained_indices(retained_dofs):
    '''
    Parameters
    ----------
    retained_dofs : numpy array (n)
        Global DOFs that are retained for the Guyan-Irons reduction.

    Returns
    -------
    Returns the indices of the global DOFs in the structural matrices
    (BCs have been imposed).
    
    '''
    dofs = inputs.dofList.flatten().astype(int)
    fixed_dofs = inputs.dofList[inputs.fixedList.astype(int) - 1].flatten().astype(int)
    
    active_dofs = np.sort([item for item in dofs if item not in fixed_dofs])

    indices = np.sort([np.where(active_dofs == item)[0][0] for item in retained_dofs])
    
    return indices

def K_bloc(K, retained):
    
    # Sort retained DOFs
    x_R = np.sort(retained).astype(int)

    # Find condensed DOFs
    n = K.shape[0]
    x_C = np.setdiff1d(np.arange(n), x_R)

    # Block decomposition
    K_RR = K[np.ix_(x_R, x_R)]
    K_CC = K[np.ix_(x_C, x_C)]
    K_RC = K[np.ix_(x_R, x_C)]
    K_CR = K[np.ix_(x_C, x_R)]
    
    return K_RR, K_CC, K_RC, K_CR


def R_from_K_bloc(K_CC_inv, K_CR):
    
    I = np.eye(K_CR.shape[1])
    R_bottom = - K_CC_inv @ K_CR
    
    return np.vstack([I, R_bottom])
    
#Define Guyan-Irons reduction matrix
def R_gi(K, retained):
    '''
    Parameters
    ----------
    K : numpy array (n x n)
        Structural stiffness matrix.
    retained : numpy array (m)
        Retained DOF indices.

    Returns
    -------
    R : numpy array (n x m)
        Guyan-Irons reduction matrix.
    '''
    # Sort retained DOFs
    x_R = np.sort(retained).astype(int)
    
    # Find condensed DOFs
    n = K.shape[0]
    x_C = np.setdiff1d(np.arange(n), x_R)
    
    #Bloc decomposition
    K_RR, K_CC, K_RC, K_CR = K_bloc(K, retained)

    # Build R (in compressed form first)
    I = np.eye(len(x_R))
    R_bottom = -np.linalg.solve(K_CC, K_CR)
    R_compact = np.vstack([I, R_bottom])

    # Now expand R_compact into full-size R by inserting rows in correct positions
    full_indices = np.concatenate([x_R, x_C])
    R = np.zeros((n, len(x_R)))
    for i, global_row in enumerate(full_indices):
        R[global_row, :] = R_compact[i, :]
    
    return R

#Define function to compute the reduced stiffness matrix
def K_gi(K, R):
    return R.T @ K @ R

#Define funuction to compute the reduced mass matrix
def M_gi(M, R):
    return R.T @ M @ R

#Define fuunction to compute the reduced force vector
def f_gi(f, R):
    return R.T @ f

