#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May  5 15:28:53 2025

@author: joeadler
"""
import re
import math

# ======= Configuration =======
n = 45  # Change this number to switch to another dataset, e.g. 30, 40, etc.

elem_filename = f'elem_{n}.txt'
node_filename = f'node_{n}.txt'

elem_outfile = 'elemListWorkpiece.txt'
node_outfile = 'nodeList.txt'
fixed_nodes_file = 'fixedNodes.txt'
elem_bars_file = 'elemListBars.txt'
machining_load_file = 'machiningLoads.txt'
# =============================

# Task 1: Process elem_n.txt -> elemListWorkpiece.txt
def process_elem_file():
    with open(elem_filename, 'r') as f:
        lines = f.readlines()

    with open(elem_outfile, 'w') as out:
        for line in lines[1:]:  # Skip header
            parts = line.strip().split('|')
            if len(parts) == 2:
                nodes = parts[1].strip()
                out.write(nodes + '\n')

# Task 2: Process node_n.txt -> nodeList.txt
def process_node_file():
    node_coords = {}
    with open(node_filename, 'r') as f:
        lines = f.readlines()

    current_label = None
    for line in lines:
        label_match = re.match(r'\s*Label\s+(\d+)', line)
        coord_match = re.search(r'Global coordinates\s*:\s*([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)', line)
        if label_match:
            current_label = int(label_match.group(1))
        elif coord_match and current_label is not None:
            x, y, z = map(float, coord_match.groups())
            node_coords[current_label] = (x, y, z)
            current_label = None

    with open(node_outfile, 'w') as out:
        for label in sorted(node_coords):
            coords = node_coords[label]
            out.write(f'{coords[0]} {coords[1]} {coords[2]}\n')

    return node_coords

# Task 3: fixedNodes.txt
def write_fixed_nodes(all_node_coords):
    with open(fixed_nodes_file, 'w') as out:
        for label, coords in all_node_coords.items():
            if coords[2] == 0 or abs(coords[2] - 103) < 1e-6:
                out.write(f'{label}\n')


# Task 4: Create lifted nodes 3mm above Z=100 nodes
def create_lifted_nodes(node_coords):
    lifted_nodes = {}
    new_node_coords = node_coords.copy()
    max_node_id = max(node_coords.keys())

    with open(elem_bars_file, 'w') as out:
        for label, coords in node_coords.items():
            x, y, z = coords
            if abs(z - 100) < 1e-6:
                max_node_id += 1
                lifted_coords = (x, y, z + 3)
                lifted_nodes[max_node_id] = lifted_coords
                new_node_coords[max_node_id] = lifted_coords
                out.write(f'{label} {max_node_id}\n')

    # Append lifted nodes to nodeList.txt
    with open(node_outfile, 'a') as out:
        for label in sorted(lifted_nodes):
            x, y, z = lifted_nodes[label]
            out.write(f'{x} {y} {z}\n')

    return new_node_coords

# Task 5: machiningLoads.txt — closest to (0, -25, 50)
def find_closest_node(node_coords):
    target = (0, -25, 50)
    min_dist = float('inf')
    closest_label = None

    for label, coords in node_coords.items():
        dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(coords, target)))
        if dist < min_dist:
            min_dist = dist
            closest_label = label

    with open(machining_load_file, 'w') as out:
        out.write(f'{closest_label}\n')

# Run all tasks
if __name__ == "__main__":
    process_elem_file()
    original_coords = process_node_file()
    updated_coords = create_lifted_nodes(original_coords)
    write_fixed_nodes(updated_coords)  # Moved here, after creating lifted nodes
    find_closest_node(updated_coords)

