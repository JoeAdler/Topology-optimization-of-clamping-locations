#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 21 13:54:11 2025

@author: joeadler
"""

import numpy as np

A = np.loadtxt("nodeList.txt")

B = np.where(A[:,0]==0)[0] + 1

C = np.where(A[:,0]==1000)[0] + 1

D = np.zeros((16,4))

for i in range(16):
    for j in range(4):
        if j==0:
            D[i,j] = C[i]
        if j==3:
            D[i,j] = -312.5

#np.savetxt("fixed_nodes.txt", B)
np.savetxt("imposed_forces.txt", D)

E = np.where(A[:,2]==25)[0] + 1
print(E)

np.savetxt("clampSurface_1.txt", E)






array1 = np.array([1, 2, 3, 4, 5])
array2 = np.array([3, 4])

# Remove elements of array1 that are in array2
result = array1[~np.isin(array1, array2)]
