"""
SENSITIVITY
-----------

Description: This code is aimed at computing the different sensitivity values of the optimization problem.

Author: J. Adler

Academic year: 2024-2025
"""

import numpy as np
import inputs
import elementary
import assembly

#Define a function that returns the sensitivity of the elementary stiffness matrix
def dKe_dx(i, x):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
    
    #Parameters
    p = assembly.p_SIMP
    E0 = assembly.E_b
    A = assembly.A_b
    
    #Elementary stiffness matrix for x=1
    Ke = elementary.Ke_bar(i, E0, A)
    
    #Sensitivity of the elementary stiffness matrix
    dKedx = p * np.power(x[i-1], p-1) * Ke
    
    return dKedx

#Define a function that returns the sensitivity of the structural stiffness matrix
def dK_dx(i, x):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
    
    #Sensitivity of the elementary stiffness matrix
    dKedx = dKe_dx(i, x)
    
    #Initialize stiffness sensitivity
    dKdx = np.zeros((inputs.dofs, inputs.dofs))
    
    #Vector containing the dofs of the i-th bar
    loc = inputs.locelBars[i-1] - 1
    
    for I in range(2 * inputs.dofPerNode):
        for J in range(2 * inputs.dofPerNode):
            ii, jj = int(loc[I]), int(loc[J])
            dKdx[ii, jj] += dKedx[I][J]
        
    #Apply the boundary conditions
    dKdx = assembly.applyBC(dKdx)
    
    return dKdx

#Define a function that returns the sensitivity of the elementary mass matrix
def dMe_dx(i):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
    
    #Parameters
    A = assembly.A_b
    rho = assembly.rho_b
    
    #Elementary mass matrix for x=1
    Me = elementary.Me_bar(i, A, rho)
    
    #Sensitivity of the elementary mass matrix
    dMedx = Me
    
    return dMedx

#Define a function that returns the sensitivity of the structural mass matrix
def dM_dx(i):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
    
    #Sensitivity of the elementary mass matrix
    dMedx = dMe_dx(i)
    
    #Initialize mass sensitivity
    dMdx = np.zeros((inputs.dofs, inputs.dofs))
    
    #Vector containing the dofs of the i-th bar
    loc = inputs.locelBars[i-1] - 1
    
    for I in range(2 * inputs.dofPerNode):
        for J in range(2 * inputs.dofPerNode):
            ii, jj = int(loc[I]), int(loc[J])
            dMdx[ii, jj] += dMedx[I][J]
        
    #Apply the boundary conditions
    dMdx = assembly.applyBC(dMdx)
    
    return dMdx

#Sensitivity of reduced stiffness matrix
def dKtilde_dx(i, x):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
        
    #List of active bar nodes
    elemListBars = inputs.elemListBars.flatten()
    fixedList = inputs.fixedList
    active_nodes = np.sort([item for item in elemListBars if item not in fixedList])
        
    #Sensitivity of the elementary stiffness matrix
    dKedx = dKe_dx(i, x)
    
    #Initialize stiffness sensitivity
    n = inputs.barElem * inputs. dofPerNode
    dKtildedx = np.zeros((n, n))
    
    #Fill the matrix
    n1, n2 = inputs.elemListBars[i-1][:]
    
    if n1 in active_nodes and n2 in active_nodes:
        raise ValueError("Problem in 'dKtilde_dx'")
        
    elif n1 in active_nodes:
        I = np.where(active_nodes == n1)[0][0]
        J = I+1
        dKtildedx[3*I:3*J, 3*I:3*J] += dKedx[:3,:3]
    
    elif n2 in active_nodes:
        I = np.where(active_nodes == n2)[0][0]
        J = I+1
        dKtildedx[3*I:3*J, 3*I:3*J] += dKedx[3:,3:]
        
    else:
        raise ValueError("Problem in 'dKtilde_dx'")
    
    return dKtildedx    

#Sensitivity of reduced mass matrix
def dMtilde_dx(i):
    if i<1 or i>inputs.barElem:
        raise ValueError("Invalid index")
    
    #List of active bar nodes
    elemListBars = inputs.elemListBars.flatten()
    fixedList = inputs.fixedList
    active_nodes = np.sort([item for item in elemListBars if item not in fixedList])
        
    #Sensitivity of the elementary mass matrix
    dMedx = dMe_dx(i)
    
    #Initialize mass sensitivity
    n = inputs.barElem * inputs. dofPerNode
    dMtildedx = np.zeros((n, n))
    
    #Fill the matrix
    n1, n2 = inputs.elemListBars[i-1][:]
    
    if n1 in active_nodes and n2 in active_nodes:
        raise ValueError("Problem in 'dMtilde_dx'")
        
    elif n1 in active_nodes:
        I = np.where(active_nodes == n1)[0][0]
        J = I+1
        dMtildedx[3*I:3*J, 3*I:3*J] += dMedx[:3,:3]
    
    elif n2 in active_nodes:
        I = np.where(active_nodes == n2)[0][0]
        J = I+1
        dMtildedx[3*I:3*J, 3*I:3*J] += dMedx[3:,3:]
        
    else:
        raise ValueError("Problem in 'dMtilde_dx'")
        
    return dMtildedx

#Define a function that returns the vector dc0_dq, i.e. the derivative of the objective function with respect to q_k
def dc0_dq(q):
    # Find the largest value in the matrix
    max_value = np.max(q)
    
    # Create a new matrix with the same shape as the original, filled with zeros
    dc0dq = np.zeros_like(q)
    
    dc0dq[q == max_value] = 2 * max_value
    
    return dc0dq

#Define a function that returns the sensitivity of the objective function
def dc0_dx(x, K, q):
    
    if q.ndim==1:
        q = q.reshape(-1, 1)
    
    bars = inputs.barElem
    
    #Initialization
    dc0dx = np.zeros(bars)
    
    b = dc0_dq(q)
    non_zero_columns = np.any(b != 0, axis=0)
    column_indices = np.where(non_zero_columns)[0]
    
    #Iterate
    for i in range(1,bars+1,1):
        dKdx = dK_dx(i, x)
        
        for s in column_indices:
            lamda = np.linalg.solve(K, b[:,s]).flatten()
            dc0dx[i-1] += -lamda @ dKdx @ q[:,s]
    
    return dc0dx

#Define derivative of the objective function with respect to the design variable
#in the reduced case
def dc0_dx_tilde(x, R, q, q_tilde, K_tilde):
    
    if q.ndim==1:
        q = q.reshape(-1,1)
        q_tilde = q_tilde.reshape(-1,1)
    
    bars = inputs.barElem
    dc0dx = np.zeros(bars)
    
    b = dc0_dq(q)
    non_zero_columns = np.any(b != 0, axis=0)
    column_indices = np.where(non_zero_columns)[0]
    
    for i in range(bars):
        dKtildedx = dKtilde_dx(i+1, x)
        
        for s in column_indices:
            lamda = np.linalg.solve(K_tilde, R.T @ b[:,s]).flatten()
            dc0dx[i] += - lamda @ dKtildedx @ q_tilde[:,s]
    
    return dc0dx

#Define the sensitivity of the first constraint function
def dc1_dx():
    return np.ones(inputs.barElem)

#Define the sensitivity of the second constraint function
def dc2_dx(x, w1, q1, reduced=False):
    #w1 is the 1st eigenfrequency squared !!
    #q1 is the 1st mode shape, which must be mass normalized (q1.T @ M @ q1 = 1) !!
    
    #Initialization
    dw1dx = np.zeros(inputs.barElem)
    
    if not reduced:
        #Iterate
        for i in range(inputs.barElem):
            dKdx = dK_dx(i+1, x)
            dMdx = dM_dx(i+1)
            #Derivative of w_1^2, where w_1 is the 1st eigenfrequency
            dw1dx[i] = q1 @ (dKdx - w1 * dMdx) @ q1
    
    else:
        #Iterate
        for i in range(inputs.barElem):
            dKtildedx = dKtilde_dx(i+1, x)
            dMtildedx = dMtilde_dx(i+1)
            #Derivative of w_1^2, where w_1 is the 1st eigenfrequency
            dw1dx[i] = q1 @ (dKtildedx - w1 * dMtildedx) @ q1
    
    return dw1dx
